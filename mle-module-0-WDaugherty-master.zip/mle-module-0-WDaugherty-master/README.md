[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-c66648af7eb3fe8bc4f294546bfd86ef473780cde1dea487d3c4ff354943c9ae.svg)](https://classroom.github.com/online_ide?assignment_repo_id=8271252&assignment_repo_type=AssignmentRepo)
# MiniTorch Module 0

<img src="https://minitorch.github.io/_images/match.png" width="100px">

* Docs: https://minitorch.github.io/

* Overview: https://minitorch.github.io/module0.html

## Paremeters


These were the parameters chosen to obtian the visualization below.

<img src="img/Screen Shot 2022-08-31 at 6.24.58 PM.png">

## Visualization

The acquired visualization.
<img src="img/mle0_image.png">